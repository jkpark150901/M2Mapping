"""APNet Unseen Classes (Zero-Shot) 테스트"""

import torch
import torch.nn as nn
import numpy as np
from pathlib import Path

from models import APNet
from awa2_data import AwA2Dataset
from awa2_image_dataset import create_awa2_dataloaders


def evaluate_unseen(model, test_loader, seen_attributes, unseen_attributes, device):
    """Unseen 클래스 평가 (Zero-Shot)
    
    Args:
        model: 학습된 모델
        test_loader: Unseen 클래스 테스트 데이터로더
        seen_attributes: Seen 클래스 attributes (40, 85)
        unseen_attributes: Unseen 클래스 attributes (10, 85)
        device: cuda/cpu
    """
    model.eval()
    correct = 0
    total = 0
    
    # 전체 attributes (seen + unseen)
    all_attributes = torch.cat([seen_attributes, unseen_attributes], dim=0).to(device)
    
    with torch.no_grad():
        for images, labels in test_loader:
            images = images.to(device)
            labels = labels.to(device)  # 0-9 (unseen class indices)
            
            # Forward with semantic matching (전체 50개 클래스에 대해)
            logits = model(images, all_attributes, use_semantic_matching=True)
            
            # Unseen 클래스만 선택 (40-49 인덱스)
            logits_unseen = logits[:, 40:]
            
            # Predictions
            predicted = logits_unseen.argmax(dim=1)
            
            total += labels.size(0)
            correct += predicted.eq(labels).sum().item()
    
    accuracy = 100. * correct / total
    return accuracy


def main():
    print("=" * 80)
    print("APNet Unseen Classes Test (Zero-Shot Learning)")
    print("=" * 80)
    
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    
    # 체크포인트 로드 (최신 semantic matching 모델)
    checkpoint_path = "results/train_semantic/20260130_024328/checkpoints/best_model.pth"
    print(f"\n체크포인트 로드: {checkpoint_path}")
    
    checkpoint = torch.load(checkpoint_path)
    config = checkpoint['config']
    
    print(f"\n모델 설정:")
    print(f"  Embedding dim: {config['embedding_dim']}")
    print(f"  Num classes (seen): {config['num_classes']}")
    
    # 데이터 로딩
    print("\n데이터 로딩...")
    dataset = AwA2Dataset()
    
    # Attributes 로드
    awa2_base_dir = "/DATA/zeroshot/Animals_with_Attributes2"
    attr_file = f"{awa2_base_dir}/predicate-matrix-binary.txt"
    all_attributes_np = np.loadtxt(attr_file)
    
    # Seen classes attributes
    seen_attr_list = []
    for class_name in dataset.seen_classes:
        class_idx = dataset.classes.index(class_name)
        seen_attr_list.append(all_attributes_np[class_idx])
    seen_attributes = torch.from_numpy(np.array(seen_attr_list)).float()
    
    # Unseen classes attributes
    unseen_attr_list = []
    for class_name in dataset.unseen_classes:
        class_idx = dataset.classes.index(class_name)
        unseen_attr_list.append(all_attributes_np[class_idx])
    unseen_attributes = torch.from_numpy(np.array(unseen_attr_list)).float()
    
    print(f"  Seen attributes: {seen_attributes.shape}")
    print(f"  Unseen attributes: {unseen_attributes.shape}")
    
    # 이미지 데이터로더
    image_dir = "/DATA/zeroshot/Animals_with_Attributes2/JPEGImages"
    _, _, test_unseen_loader = create_awa2_dataloaders(
        image_dir,
        dataset.seen_classes,
        dataset.unseen_classes,
        batch_size=64,
        num_workers=4
    )
    
    print(f"  Test unseen: {len(test_unseen_loader)} batches")
    
    # 모델 생성 및 로드
    print("\n모델 로드...")
    
    # 전체 50개 클래스로 모델 생성 (zero-shot 위해)
    model = APNet(
        visual_dim=config['visual_dim'],
        attribute_dim=config['attribute_dim'],
        embedding_dim=config['embedding_dim'],
        num_classes=50,  # 전체 클래스 (semantic matching에서는 사용 안함)
        num_heads=config.get('num_heads', 4),
        num_layers=config.get('num_layers', 3),
        dropout=config.get('dropout', 0.3),
        pretrained=False,
        freeze_backbone=False
    ).to(device)
    
    # Weight 로드 (semantic matching 모델이므로 classifier 제외)
    state_dict = checkpoint['model_state_dict']
    
    # Classifier weight는 제거 (semantic matching 사용)
    keys_to_remove = [k for k in state_dict.keys() if 'classifier' in k]
    for key in keys_to_remove:
        del state_dict[key]
    
    model.load_state_dict(state_dict, strict=False)
    model.eval()
    
    print("  ✓ 모델 로드 완료 (semantic matching mode)")
    
    # Unseen 클래스 평가
    print("\n" + "=" * 80)
    print("Zero-Shot Evaluation on Unseen Classes")
    print("=" * 80)
    
    unseen_acc = evaluate_unseen(
        model, test_unseen_loader, seen_attributes, unseen_attributes, device
    )
    
    print(f"\n결과:")
    print(f"  Unseen Classes Accuracy: {unseen_acc:.2f}%")
    print(f"  (Random baseline: {100/10:.2f}%)")
    
    # Seen 클래스 정보
    print(f"\n학습된 Seen Classes (40개):")
    for i, cls in enumerate(dataset.seen_classes[:5]):
        print(f"  {cls}", end="  ")
    print("...")
    
    print(f"\nUnseen Classes (10개):")
    for cls in dataset.unseen_classes:
        print(f"  {cls}", end="  ")
    print()
    
    print("\n" + "=" * 80)


if __name__ == "__main__":
    main()
