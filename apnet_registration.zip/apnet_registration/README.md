# APNet Zero-Shot Learning - AWA2

**Animals with Attributes 2 (AWA2) 데이터셋에서 개선된 APNet 구현**

ResNet-101 기반 Zero-Shot Learning으로 **Seen 95.2%**, **Unseen 66.32%** 정확도 달성

---

## 📋 프로젝트 구조

```
zeroshot/
├── 학습 및 평가
│   ├── train_apnet_semantic.py      # 메인 학습 스크립트
│   ├── test_unseen.py               # Zero-shot 평가
│   └── visualize_unseen_results.py  # 결과 시각화
│
├── 데이터 로더
│   ├── awa2_data.py                 # 데이터셋 관리
│   └── awa2_image_dataset.py        # 이미지 로딩
│
├── 모델 (models/)
│   ├── apnet.py                     # APNet 메인 모델
│   ├── attribute_propagation.py     # Simplified GAT
│   ├── feature_extractor.py         # ResNet-101
│   ├── visual_embedding.py          # Visual projection
│   ├── semantic_encoder.py          # Attribute encoder
│   └── graph_attention.py           # GAT layers
│
├── 문서
│   ├── README.md                    # 이 파일
│   ├── MODULES.md                   # 모듈 구조 상세 설명
│   └── requirements.txt             # 의존성
│
└── results/
    └── train_semantic/
        └── 20260130_024328/         # 학습된 모델 및 로그
```

---

## 🚀 빠른 시작

### 1. 환경 설정

```bash
# 가상환경 생성 및 활성화
python -m venv .venv
source .venv/bin/activate  # Linux/Mac
# .venv\Scripts\activate    # Windows

# 의존성 설치
pip install -r requirements.txt
```

### 2. 데이터셋 준비

AWA2 데이터셋은 `/DATA/zeroshot/Animals_with_Attributes2/` 경로에 준비되어 있어야 합니다.

**필요한 파일:**
- `JPEGImages/`: 37,322개 동물 이미지
- `predicate-matrix-binary.txt`: 85차원 binary attributes
- `classes.txt`, `trainclasses.txt`, `testclasses.txt`: 클래스 정의

**데이터셋 구조:**
- 50개 클래스 (동물 종)
- 40개 seen classes (학습용)
- 10개 unseen classes (평가용): 
  - bobcat, chimpanzee, cow, deer, dolphin, giant panda, lion, Persian cat, pig, zebra
- 85개 semantic attributes (binary): 
  - ex) "has fur", "has tail", "black colored", "can fly" 등

### 3. 학습

```bash
python train_apnet_semantic.py
```

**학습 파라미터:**
- Batch size: 64
- Learning rate: 5e-4
- Epochs: 50
- Temperature: 0.07
- Optimizer: Adam

**결과 저장 위치:** `results/train_semantic/{timestamp}/`
- `checkpoints/best_model.pth`: 최고 성능 모델
- `logs/training.log`: 학습 로그
- `plots/`: 학습 곡선

### 4. 평가 (Zero-Shot)

```bash
python test_unseen.py
```

Unseen 10개 클래스에 대한 zero-shot 성능 평가

### 5. 시각화

```bash
python visualize_unseen_results.py
```

**생성되는 시각화:**
- `confusion_matrix.png`: Confusion matrix
- `class_accuracy.png`: 클래스별 정확도
- `prediction_distribution.png`: 예측 분포
- `error_analysis.json`: 상세 오류 분석

---

## 📊 실험 결과

### 최종 성능

| Metric | Accuracy |
|--------|----------|
| **Seen Classes** | **95.2%** |
| **Unseen Classes (ZSL)** | **66.32%** |
| Random Baseline | 10.0% |

### Unseen 클래스별 정확도

| 클래스 | 정확도 | 주요 오류 |
|-------|--------|-----------|
| **Deer** | **95.5%** | cow (2.3%) |
| **Zebra** | **91.6%** | cow (4.8%) |
| **Dolphin** | **85.1%** | bobcat (7.2%) |
| **Cow** | **84.3%** | deer (5.8%) |
| Pig | 73.1% | cow (14.9%) |
| Persian cat | 68.9% | bobcat (15.8%) |
| Chimpanzee | 63.4% | giant panda (14.2%) |
| Bobcat | 20.5% | zebra (39.3%), lion (16.8%) |
| Lion | 19.6% | zebra (41.9%), bobcat (15.4%) |
| **Giant panda** | **3.09%** | raccoon (75.6%) |

**주요 발견:**
- 독특한 외형 특징을 가진 클래스 (deer, zebra, dolphin)는 높은 정확도
- 유사한 속성을 공유하는 클래스 간 혼동 (lion↔zebra, giant panda→raccoon)
- Semantic attributes가 클래스를 구분하기에 충분한 경우 성공적

---

## 🔧 주요 개선사항

### 1. Gradient Vanishing 해결
- **문제**: ReLU + BatchNorm + L2 Normalization 조합으로 gradient 소실
- **해결**: `visual_embedding.py`, `semantic_encoder.py`에서 ReLU와 BatchNorm 제거
- **효과**: 2-3% → 95.2% seen accuracy

### 2. GAT 단순화
- **문제**: 3-layer GAT가 너무 복잡하여 수렴 실패
- **해결**: 1-layer GAT + residual connection으로 단순화 (`attribute_propagation.py`)
- **효과**: 안정적인 학습, 빠른 수렴

### 3. Temperature Scaling 최적화
- **방법**: Cosine similarity / temperature (0.07)
- **코드**:
```python
visual_norm = F.normalize(visual_emb, p=2, dim=1)
semantic_norm = F.normalize(semantic_prototypes, p=2, dim=1)
logits = torch.mm(visual_norm, semantic_norm.t()) / 0.07
```

### 4. End-to-End Training
- **접근**: 2-stage 대신 처음부터 semantic matching으로 학습
- **효과**: Stage1→Stage2 성능 붕괴 방지

---

## 🎯 Zero-Shot Learning 개념

### Zero-Shot Learning (ZSL)
- **학습**: Seen classes만 사용 (40개)
- **평가**: Unseen classes만 예측 (10개)
- **핵심**: Semantic attributes를 통한 지식 전이
- **가정**: 테스트 샘플은 항상 unseen class

### Semantic Attributes
- **역할**: Seen과 Unseen classes 간의 연결고리
- **예시**: "has fur", "black colored", "can swim"
- **AWA2**: 85개 binary attributes
- **전이 메커니즘**: 
  1. Seen classes로 attribute-visual 관계 학습
  2. Unseen classes의 attributes로 visual 특징 추론

### Knowledge Graph
- **구성**: Attribute cosine similarity 기반 인접 행렬
- **용도**: Graph Attention Network (GAT)로 attribute 정보 전파
- **효과**: 클래스 간 구조적 관계 활용

---

## 💻 시스템 요구사항

- **GPU**: CUDA 지원 GPU (NVIDIA H200 NVL에서 테스트됨)
- **메모리**: GPU 8GB 이상 권장
- **Python**: 3.8+
- **PyTorch**: 2.10.0+cu128

**주요 의존성:**
- torch==2.10.0+cu128
- torchvision==0.20.0+cu128
- numpy==2.2.6
- scipy==1.15.3
- matplotlib==3.10.8
- scikit-learn==1.7.2

---

## 📁 결과 파일

### 학습 결과 (`results/train_semantic/20260130_024328/`)

```
checkpoints/
├── best_model.pth           # 최고 성능 모델 (epoch 3)
└── checkpoint_epoch_*.pth   # 에폭별 체크포인트

logs/
├── training.log             # 상세 학습 로그
└── metrics.json             # 에폭별 메트릭

visualizations/
└── unseen_test/             # 평가 시각화
    ├── confusion_matrix.png
    ├── class_accuracy.png
    ├── prediction_distribution.png
    └── error_analysis.json
```

---

## 🔍 문제 해결

### 학습이 수렴하지 않음
- Temperature 값 확인 (0.07 권장)
- Learning rate 조정 (5e-4 → 1e-4)
- Batch size 감소 (메모리 부족 시)

### Unseen 정확도가 낮음
- 정상입니다 (Zero-shot은 어려운 문제)
- 66.32%는 random baseline 10%보다 6배 이상 높음
- Attribute 품질이 성능에 큰 영향

### OOM (Out of Memory)
- Batch size 감소: 64 → 32 → 16
- `freeze_backbone=True` 활성화 (초기 학습 시)

---

## 📚 참고 자료

- **APNet 논문**: Lu et al. "Attribute Propagation Network for Graph Zero-shot Learning" (AAAI 2020)
- **AWA2 데이터셋**: [Animals with Attributes 2](https://cvml.ist.ac.at/AwA2/)
- **Zero-Shot Learning 리뷰**: Xian et al. "Zero-Shot Learning - A Comprehensive Evaluation" (TPAMI 2018)

---

## 📄 라이선스

연구 및 교육 목적으로 사용 가능
