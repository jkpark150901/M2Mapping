"""APNet End-to-End 학습 (논문 방식)

처음부터 semantic matching으로 학습
"""

import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
from pathlib import Path
from datetime import datetime
import json

from models import APNet
from awa2_data import AwA2Dataset
from awa2_image_dataset import create_awa2_dataloaders


def train_epoch(model, train_loader, attributes, criterion, optimizer, device):
    """한 epoch 학습"""
    model.train()
    total_loss = 0
    correct = 0
    total = 0
    
    attributes = attributes.to(device)
    
    for batch_idx, (images, labels) in enumerate(train_loader):
        images, labels = images.to(device), labels.to(device)
        
        optimizer.zero_grad()
        
        # Forward (semantic matching 사용)
        logits = model(images, attributes, use_semantic_matching=True)
        
        # Loss
        loss = criterion(logits, labels)
        
        # Backward
        loss.backward()
        
        # Gradient clipping
        torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=5.0)
        
        optimizer.step()
        
        # Statistics
        total_loss += loss.item()
        _, predicted = logits.max(1)
        total += labels.size(0)
        correct += predicted.eq(labels).sum().item()
        
        if (batch_idx + 1) % 50 == 0:
            print(f'  Batch [{batch_idx+1}/{len(train_loader)}] '
                  f'Loss: {loss.item():.4f} '
                  f'Acc: {100.*correct/total:.2f}%')
    
    avg_loss = total_loss / len(train_loader)
    accuracy = 100. * correct / total
    
    return avg_loss, accuracy


def evaluate(model, test_loader, attributes, device):
    """모델 평가"""
    model.eval()
    correct = 0
    total = 0
    
    attributes = attributes.to(device)
    
    with torch.no_grad():
        for images, labels in test_loader:
            images, labels = images.to(device), labels.to(device)
            
            # Forward
            logits = model(images, attributes, use_semantic_matching=True)
            
            # Predictions
            _, predicted = logits.max(1)
            
            total += labels.size(0)
            correct += predicted.eq(labels).sum().item()
    
    accuracy = 100. * correct / total
    return accuracy


def main():
    print("=" * 80)
    print("APNet End-to-End Training (논문 방식)")
    print("=" * 80)
    
    # 결과 저장 디렉토리
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    result_dir = Path(f"results/train_semantic/{timestamp}")
    result_dir.mkdir(parents=True, exist_ok=True)
    
    checkpoint_dir = result_dir / "checkpoints"
    checkpoint_dir.mkdir(exist_ok=True)
    
    print(f"\n[결과 저장 경로]")
    print(f"  {result_dir}")
    
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    
    # 설정
    config = {
        'visual_dim': 2048,
        'attribute_dim': 85,
        'embedding_dim': 512,
        'num_classes': 40,
        'num_heads': 4,
        'num_layers': 3,
        'dropout': 0.3,
        'batch_size': 64,
        'epochs': 50,
        'lr': 5e-4,  # 중간 learning rate
        'weight_decay': 1e-4,
        'unfreeze_epoch': 10,
    }
    
    print(f"\n[설정]")
    print(f"  Device: {device}")
    print(f"  Epochs: {config['epochs']}")
    print(f"  Learning rate: {config['lr']}")
    print(f"  Semantic matching: From start")
    
    # 설정 저장
    with open(result_dir / "config.json", 'w') as f:
        json.dump(config, f, indent=2)
    
    # 데이터 로딩
    print("\n" + "=" * 80)
    print("데이터 로딩")
    print("=" * 80)
    
    dataset = AwA2Dataset()
    
    # Attributes 로드
    awa2_base_dir = "/DATA/zeroshot/Animals_with_Attributes2"
    attr_file = f"{awa2_base_dir}/predicate-matrix-binary.txt"
    all_attributes = np.loadtxt(attr_file)
    
    seen_attr_list = []
    for class_name in dataset.seen_classes:
        class_idx = dataset.classes.index(class_name)
        seen_attr_list.append(all_attributes[class_idx])
    
    attributes = torch.from_numpy(np.array(seen_attr_list)).float()
    
    print(f"  Attributes: {attributes.shape}")
    
    # 이미지 데이터로더
    image_dir = "/DATA/zeroshot/Animals_with_Attributes2/JPEGImages"
    
    train_loader, test_seen_loader, _ = create_awa2_dataloaders(
        image_dir,
        dataset.seen_classes,
        dataset.unseen_classes,
        batch_size=config['batch_size'],
        num_workers=4
    )
    
    print(f"  Train: {len(train_loader)} batches")
    print(f"  Test Seen: {len(test_seen_loader)} batches")
    
    # 모델 생성
    print("\n" + "=" * 80)
    print("모델 생성")
    print("=" * 80)
    
    model = APNet(
        visual_dim=config['visual_dim'],
        attribute_dim=config['attribute_dim'],
        embedding_dim=config['embedding_dim'],
        num_classes=config['num_classes'],
        num_heads=config['num_heads'],
        num_layers=config['num_layers'],
        dropout=config['dropout'],
        pretrained=True,
        freeze_backbone=True
    ).to(device)
    
    total_params = sum(p.numel() for p in model.parameters())
    trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    print(f"  전체: {total_params:,}")
    print(f"  학습 가능: {trainable_params:,}")
    
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.Adam(model.parameters(), lr=config['lr'], weight_decay=config['weight_decay'])
    scheduler = optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=config['epochs'])
    
    history = {
        'train_loss': [],
        'train_acc': [],
        'test_acc': [],
    }
    
    # 학습
    print("\n" + "=" * 80)
    print("학습 시작")
    print("=" * 80)
    
    best_acc = 0
    
    for epoch in range(config['epochs']):
        print(f"\n[Epoch {epoch+1}/{config['epochs']}]")
        
        # Unfreeze backbone
        if epoch == config.get('unfreeze_epoch', 10):
            print(f"\n  🔓 Unfreezing ResNet backbone...")
            model.visual_extractor.unfreeze_backbone()
            optimizer = optim.Adam(model.parameters(), lr=config['lr']/10, weight_decay=config['weight_decay'])
            scheduler = optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=config['epochs']-epoch)
        
        train_loss, train_acc = train_epoch(
            model, train_loader, attributes, criterion, optimizer, device
        )
        
        print(f'\nEpoch {epoch+1} Summary:')
        print(f'  Train Loss: {train_loss:.4f}')
        print(f'  Train Acc: {train_acc:.2f}%')
        
        history['train_loss'].append(float(train_loss))
        history['train_acc'].append(float(train_acc))
        
        # 평가
        if (epoch + 1) % 5 == 0 or epoch < 5:
            test_acc = evaluate(model, test_seen_loader, attributes, device)
            print(f'  Test Acc: {test_acc:.2f}%')
            history['test_acc'].append(float(test_acc))
            
            if test_acc > best_acc:
                best_acc = test_acc
                torch.save({
                    'epoch': epoch,
                    'model_state_dict': model.state_dict(),
                    'optimizer_state_dict': optimizer.state_dict(),
                    'test_acc': test_acc,
                    'config': config
                }, checkpoint_dir / 'best_model.pth')
                print(f'  ✓ Best model saved!')
        
        scheduler.step()
    
    # 히스토리 저장
    with open(result_dir / 'history.json', 'w') as f:
        json.dump(history, f, indent=2)
    
    # 최종 결과
    final_results = {
        'best_acc': float(best_acc),
        'timestamp': timestamp,
        'config': config
    }
    
    with open(result_dir / 'final_results.json', 'w') as f:
        json.dump(final_results, f, indent=2)
    
    print("\n" + "=" * 80)
    print("학습 완료!")
    print(f"  Best Test Acc: {best_acc:.2f}%")
    print(f"  결과 저장: {result_dir}")
    print("=" * 80)


if __name__ == "__main__":
    main()
