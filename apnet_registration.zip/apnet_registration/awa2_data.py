"""AwA2 (Animals with Attributes 2) 데이터셋 다운로드 및 로딩

AwA2는 Zero-Shot Learning의 표준 벤치마크:
- 50개 동물 클래스
- 37,322 이미지
- 85개 binary attributes
- 표준 split: 40 seen classes, 10 unseen classes

데이터 출처: https://cvml.ist.ac.at/AwA2/
"""

import os
import numpy as np
import scipy.io as sio
import urllib.request
import zipfile
from pathlib import Path


class AwA2Dataset:
    """AwA2 데이터셋 관리 클래스"""
    
    def __init__(self, data_dir='./data/AwA2'):
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        
        # 클래스 이름들 (알파벳 순서)
        self.classes = [
            'antelope', 'grizzly+bear', 'killer+whale', 'beaver', 'dalmatian',
            'persian+cat', 'horse', 'german+shepherd', 'blue+whale', 'siamese+cat',
            'skunk', 'mole', 'tiger', 'hippopotamus', 'leopard',
            'moose', 'spider+monkey', 'humpback+whale', 'elephant', 'gorilla',
            'ox', 'fox', 'sheep', 'seal', 'chimpanzee',
            'hamster', 'squirrel', 'rhinoceros', 'rabbit', 'bat',
            'giraffe', 'wolf', 'chihuahua', 'rat', 'weasel',
            'otter', 'buffalo', 'zebra', 'giant+panda', 'deer',
            'bobcat', 'pig', 'lion', 'mouse', 'polar+bear',
            'collie', 'walrus', 'raccoon', 'cow', 'dolphin'
        ]
        
        # 표준 split (Xian et al. 2017)
        # Seen classes (학습용 40개)
        self.seen_classes = [
            'antelope', 'grizzly+bear', 'killer+whale', 'beaver', 'dalmatian',
            'persian+cat', 'horse', 'german+shepherd', 'blue+whale', 'siamese+cat',
            'skunk', 'mole', 'tiger', 'hippopotamus', 'leopard',
            'moose', 'spider+monkey', 'humpback+whale', 'elephant', 'gorilla',
            'ox', 'fox', 'sheep', 'seal', 'chimpanzee',
            'hamster', 'squirrel', 'rhinoceros', 'rabbit', 'bat',
            'giraffe', 'wolf', 'chihuahua', 'weasel', 'otter',
            'buffalo', 'pig', 'mouse', 'polar+bear', 'collie'
        ]
        
        # Unseen classes (테스트용 10개)
        self.unseen_classes = [
            'bobcat', 'rat', 'raccoon', 'deer', 'dolphin',
            'giant+panda', 'walrus', 'cow', 'lion', 'zebra'
        ]
        
        self.seen_idx = [self.classes.index(c) for c in self.seen_classes]
        self.unseen_idx = [self.classes.index(c) for c in self.unseen_classes]
        
        print(f"AwA2 데이터셋 초기화")
        print(f"  데이터 디렉토리: {self.data_dir}")
        print(f"  Seen classes: {len(self.seen_classes)}")
        print(f"  Unseen classes: {len(self.unseen_classes)}")
    
    def download_xlsa17(self):
        """xlsa17 데이터 다운로드 (ResNet features + splits)"""
        print("\n" + "="*70)
        print("AwA2 데이터 다운로드")
        print("="*70)
        
        # xlsa17 데이터 (Xian et al. 2017)
        url = "https://datasets.d2.mpi-inf.mpg.de/xian/xlsa17.zip"
        zip_path = self.data_dir / "xlsa17.zip"
        extract_path = self.data_dir / "xlsa17"
        
        if extract_path.exists():
            print("✓ xlsa17 데이터가 이미 존재합니다.")
            return
        
        print(f"다운로드 중: {url}")
        print("(약 2GB, 시간이 걸릴 수 있습니다...)")
        
        try:
            urllib.request.urlretrieve(url, zip_path)
            print(f"✓ 다운로드 완료: {zip_path}")
            
            print("압축 해제 중...")
            with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                zip_ref.extractall(self.data_dir)
            print(f"✓ 압축 해제 완료: {extract_path}")
            
            # 압축 파일 삭제
            zip_path.unlink()
            print("✓ 임시 파일 정리 완료")
            
        except Exception as e:
            print(f"✗ 다운로드 실패: {e}")
            print("\n수동 다운로드 방법:")
            print(f"1. 브라우저에서 다운로드: {url}")
            print(f"2. 압축 해제: {self.data_dir}")
            raise
    
    def load_data(self):
        """AwA2 데이터 로딩
        
        Returns:
            features: (N, 2048) ResNet-101 features
            labels: (N,) 클래스 레이블 (0-49)
            attributes: (50, 85) 클래스별 attribute matrix
            seen_mask: (N,) bool array - True if sample is from seen class
        """
        print("\n" + "="*70)
        print("AwA2 데이터 로딩")
        print("="*70)
        
        data_path = self.data_dir / "xlsa17" / "data" / "AWA2"
        
        # ResNet-101 features 로딩
        res101_file = data_path / "res101.mat"
        if not res101_file.exists():
            raise FileNotFoundError(
                f"ResNet features를 찾을 수 없습니다: {res101_file}\n"
                "먼저 download_xlsa17()을 실행하세요."
            )
        
        print("ResNet-101 features 로딩...")
        mat_data = sio.loadmat(str(res101_file))
        features = mat_data['features'].T  # (N, 2048)
        labels = mat_data['labels'].flatten() - 1  # 1-indexed → 0-indexed
        
        # Attributes 로딩
        att_splits_file = data_path / "att_splits.mat"
        print("Attributes 및 splits 로딩...")
        att_data = sio.loadmat(str(att_splits_file))
        attributes = att_data['att'].T  # (50, 85)
        
        # Train/test split
        train_loc = att_data['train_loc'].flatten() - 1
        test_seen_loc = att_data['val_loc'].flatten() - 1
        test_unseen_loc = att_data['test_unseen_loc'].flatten() - 1
        
        print(f"\n데이터 로딩 완료:")
        print(f"  Features shape: {features.shape}")
        print(f"  Labels shape: {labels.shape}")
        print(f"  Attributes shape: {attributes.shape}")
        print(f"  Train samples: {len(train_loc)}")
        print(f"  Test seen samples: {len(test_seen_loc)}")
        print(f"  Test unseen samples: {len(test_unseen_loc)}")
        
        return {
            'features': features,
            'labels': labels,
            'attributes': attributes,
            'train_loc': train_loc,
            'test_seen_loc': test_seen_loc,
            'test_unseen_loc': test_unseen_loc,
            'seen_classes': np.array(self.seen_idx),
            'unseen_classes': np.array(self.unseen_idx),
            'class_names': self.classes
        }
    
    def get_attribute_names(self):
        """85개 attribute 이름들 반환"""
        return [
            'black', 'white', 'blue', 'brown', 'gray', 'orange', 'red', 'yellow',
            'patches', 'spots', 'stripes', 'furry', 'hairless', 'toughskin',
            'big', 'small', 'bulbous', 'lean',
            'flippers', 'hands', 'hooves', 'pads', 'paws', 'longleg', 'longneck', 'tail',
            'chewteeth', 'meatteeth', 'buckteeth', 'strainteeth',
            'horns', 'claws', 'tusks',
            'smelly', 'flys', 'hops', 'swims', 'tunnels', 'walks', 'fast', 'slow',
            'strong', 'weak', 'muscle', 'bipedal', 'quadrapedal',
            'active', 'inactive', 'nocturnal', 'hibernate',
            'agility', 'fish', 'meat', 'plankton', 'vegetation', 'insects',
            'forager', 'grazer', 'hunter', 'scavenger', 'skimmer', 'stalker',
            'newworld', 'oldworld', 'arctic', 'coastal', 'desert', 'bush',
            'plains', 'forest', 'fields', 'jungle', 'mountains', 'ocean', 'ground',
            'water', 'tree', 'cave', 'fierce', 'timid', 'smart', 'group', 'solitary', 'nestspot', 'domestic'
        ]


def create_awa2_knowledge_graph(attributes, seen_idx, unseen_idx, threshold=0.3):
    """Attribute 유사도 기반 Knowledge Graph 생성
    
    Args:
        attributes: (50, 85) 클래스별 attribute matrix
        seen_idx: Seen classes 인덱스
        unseen_idx: Unseen classes 인덱스  
        threshold: 연결 생성 임계값
        
    Returns:
        adj_matrix: (50, 50) 인접 행렬
    """
    import torch
    
    print("\n" + "="*70)
    print("Knowledge Graph 생성 (Attribute 기반)")
    print("="*70)
    
    num_classes = attributes.shape[0]
    attributes_tensor = torch.from_numpy(attributes).float()
    
    # Cosine similarity 계산
    # (50, 85) x (85, 50) = (50, 50)
    norm_attributes = attributes_tensor / (attributes_tensor.norm(dim=1, keepdim=True) + 1e-8)
    similarity = torch.mm(norm_attributes, norm_attributes.t())
    
    # Threshold 적용 + self-connection
    adj_matrix = torch.zeros_like(similarity)
    adj_matrix[similarity > threshold] = similarity[similarity > threshold]
    
    # Self-connection 강화
    for i in range(num_classes):
        adj_matrix[i, i] = 1.0
    
    # Row-wise normalization
    row_sum = adj_matrix.sum(dim=1, keepdim=True)
    adj_matrix = adj_matrix / (row_sum + 1e-8)
    
    # 연결 통계
    num_connections = (adj_matrix > 0).sum().item() - num_classes  # self 제외
    
    print(f"  클래스 수: {num_classes}")
    print(f"  Attribute 차원: {attributes.shape[1]}")
    print(f"  유사도 threshold: {threshold}")
    print(f"  총 연결 수: {num_connections}")
    print(f"  평균 이웃 수: {num_connections / num_classes:.1f}")
    
    # Unseen classes의 연결 확인
    print(f"\n  Unseen classes 연결 상태:")
    for idx in unseen_idx:
        neighbors = (adj_matrix[idx] > 0).sum().item() - 1  # self 제외
        seen_neighbors = sum(1 for i in seen_idx if adj_matrix[idx, i] > 0)
        print(f"    Class {idx}: {neighbors} neighbors ({seen_neighbors} from seen)")
    
    return adj_matrix


if __name__ == "__main__":
    # 테스트
    dataset = AwA2Dataset()
    
    # 데이터 다운로드 (처음 한 번만)
    # dataset.download_xlsa17()
    
    # 데이터 로딩
    try:
        data = dataset.load_data()
        print("\n✓ 데이터 로딩 성공!")
        
        # Knowledge graph 생성
        adj_matrix = create_awa2_knowledge_graph(
            data['attributes'],
            data['seen_classes'],
            data['unseen_classes']
        )
        
        print("\n✓ Knowledge graph 생성 완료!")
        
    except FileNotFoundError as e:
        print(f"\n✗ {e}")
        print("\n먼저 데이터를 다운로드하세요:")
        print("  dataset.download_xlsa17()")
