"""AWA2 이미지 데이터셋 - PyTorch Dataset 클래스

원본 이미지를 직접 로드하여 학습에 사용
"""

import os
from pathlib import Path
from PIL import Image
import torch
from torch.utils.data import Dataset
from torchvision import transforms


class AwA2ImageDataset(Dataset):
    """AWA2 원본 이미지 데이터셋
    
    Args:
        image_dir: 이미지 디렉토리 경로 (JPEGImages)
        class_names: 클래스 이름 리스트
        transform: 이미지 변환 (default: ImageNet normalization)
        max_images_per_class: 클래스당 최대 이미지 수 (메모리 절약용, None이면 전체)
    """
    def __init__(self, image_dir, class_names, transform=None, max_images_per_class=None):
        self.image_dir = Path(image_dir)
        self.class_names = class_names
        self.max_images_per_class = max_images_per_class
        
        # Default transform: ImageNet normalization
        if transform is None:
            self.transform = transforms.Compose([
                transforms.Resize(256),
                transforms.CenterCrop(224),
                transforms.ToTensor(),
                transforms.Normalize(mean=[0.485, 0.456, 0.406],
                                   std=[0.229, 0.224, 0.225])
            ])
        else:
            self.transform = transform
        
        # 이미지 경로와 레이블 수집
        self.image_paths = []
        self.labels = []
        
        for class_idx, class_name in enumerate(class_names):
            class_dir = self.image_dir / class_name
            if not class_dir.exists():
                print(f"Warning: {class_dir} not found, skipping...")
                continue
            
            # 클래스별 이미지 파일 수집
            image_files = sorted(list(class_dir.glob('*.jpg')))
            
            # 최대 이미지 수 제한
            if max_images_per_class is not None:
                image_files = image_files[:max_images_per_class]
            
            for img_path in image_files:
                self.image_paths.append(img_path)
                self.labels.append(class_idx)
        
        print(f"AWA2 이미지 데이터셋 생성:")
        print(f"  클래스 수: {len(class_names)}")
        print(f"  총 이미지 수: {len(self.image_paths)}")
        print(f"  클래스당 평균: {len(self.image_paths) / len(class_names):.1f}")
    
    def __len__(self):
        return len(self.image_paths)
    
    def __getitem__(self, idx):
        """
        Returns:
            image: (3, 224, 224) 텐서
            label: 클래스 인덱스
        """
        img_path = self.image_paths[idx]
        label = self.labels[idx]
        
        # 이미지 로드
        try:
            image = Image.open(img_path).convert('RGB')
            if self.transform:
                image = self.transform(image)
            return image, label
        except Exception as e:
            print(f"Error loading {img_path}: {e}")
            # 에러 시 더미 이미지 반환
            return torch.zeros(3, 224, 224), label


def create_awa2_dataloaders(
    image_dir,
    seen_classes,
    unseen_classes,
    batch_size=32,
    num_workers=4,
    max_images_per_class=None
):
    """AWA2 이미지 데이터로더 생성
    
    Args:
        image_dir: 이미지 디렉토리 (/DATA/zeroshot/Animals_with_Attributes2/JPEGImages)
        seen_classes: Seen class 이름 리스트
        unseen_classes: Unseen class 이름 리스트
        batch_size: 배치 크기
        num_workers: 데이터 로딩 워커 수
        max_images_per_class: 클래스당 최대 이미지 수
        
    Returns:
        train_loader: Seen classes 학습 로더
        test_seen_loader: Seen classes 테스트 로더
        test_unseen_loader: Unseen classes 테스트 로더
    """
    from torch.utils.data import DataLoader, random_split
    
    # Train/Test transforms
    train_transform = transforms.Compose([
        transforms.Resize(256),
        transforms.RandomResizedCrop(224),
        transforms.RandomHorizontalFlip(),
        transforms.ColorJitter(brightness=0.2, contrast=0.2, saturation=0.2),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406],
                           std=[0.229, 0.224, 0.225])
    ])
    
    test_transform = transforms.Compose([
        transforms.Resize(256),
        transforms.CenterCrop(224),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406],
                           std=[0.229, 0.224, 0.225])
    ])
    
    # Seen classes 데이터셋
    seen_dataset = AwA2ImageDataset(
        image_dir,
        seen_classes,
        transform=train_transform,
        max_images_per_class=max_images_per_class
    )
    
    # Train/Test split (80/20)
    train_size = int(0.8 * len(seen_dataset))
    test_size = len(seen_dataset) - train_size
    train_dataset, test_seen_dataset = random_split(
        seen_dataset,
        [train_size, test_size],
        generator=torch.Generator().manual_seed(42)
    )
    
    # Test transform 적용
    test_seen_dataset.dataset.transform = test_transform
    
    # Unseen classes 데이터셋 (test only)
    test_unseen_dataset = AwA2ImageDataset(
        image_dir,
        unseen_classes,
        transform=test_transform,
        max_images_per_class=max_images_per_class
    )
    
    # 데이터로더 생성
    train_loader = DataLoader(
        train_dataset,
        batch_size=batch_size,
        shuffle=True,
        num_workers=num_workers,
        pin_memory=True
    )
    
    test_seen_loader = DataLoader(
        test_seen_dataset,
        batch_size=batch_size,
        shuffle=False,
        num_workers=num_workers,
        pin_memory=True
    )
    
    test_unseen_loader = DataLoader(
        test_unseen_dataset,
        batch_size=batch_size,
        shuffle=False,
        num_workers=num_workers,
        pin_memory=True
    )
    
    print(f"\n데이터로더 생성 완료:")
    print(f"  Train: {len(train_loader)} batches ({len(train_dataset)} images)")
    print(f"  Test Seen: {len(test_seen_loader)} batches ({len(test_seen_dataset)} images)")
    print(f"  Test Unseen: {len(test_unseen_loader)} batches ({len(test_unseen_dataset)} images)")
    
    return train_loader, test_seen_loader, test_unseen_loader


if __name__ == "__main__":
    # 테스트
    image_dir = "/DATA/zeroshot/Animals_with_Attributes2/JPEGImages"
    
    from awa2_data import AwA2Dataset
    dataset = AwA2Dataset()
    
    train_loader, test_seen_loader, test_unseen_loader = create_awa2_dataloaders(
        image_dir,
        dataset.seen_classes,
        dataset.unseen_classes,
        batch_size=16,
        num_workers=2,
        max_images_per_class=50  # 테스트용
    )
    
    # 첫 배치 확인
    images, labels = next(iter(train_loader))
    print(f"\n첫 배치 확인:")
    print(f"  Images shape: {images.shape}")
    print(f"  Labels shape: {labels.shape}")
    print(f"  Labels: {labels[:5]}")
