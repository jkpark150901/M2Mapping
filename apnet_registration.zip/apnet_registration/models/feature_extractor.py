"""Visual Feature Extractor - ResNet 기반 이미지 feature 추출"""

import torch
import torch.nn as nn
import torchvision.models as models


class ResNetFeatureExtractor(nn.Module):
    """ResNet 기반 feature extractor
    
    Args:
        feature_dim: 출력 feature 차원 (default: 2048)
        pretrained: ImageNet pretrained weights 사용 여부 (default: True)
        freeze_backbone: Backbone freeze 여부 (default: False)
    """
    def __init__(self, feature_dim=2048, pretrained=True, freeze_backbone=False):
        super(ResNetFeatureExtractor, self).__init__()
        
        # ResNet-101 백본 로드
        resnet = models.resnet101(pretrained=pretrained)
        
        # FC layer 제거하고 feature만 추출
        self.backbone = nn.Sequential(*list(resnet.children())[:-1])
        
        # Backbone freeze 옵션
        if freeze_backbone:
            for param in self.backbone.parameters():
                param.requires_grad = False
        
        # Feature dimension이 2048이 아닐 경우 projection layer 추가
        self.projection = None
        if feature_dim != 2048:
            self.projection = nn.Sequential(
                nn.Linear(2048, feature_dim),
                nn.ReLU(),
                nn.Dropout(0.3)
            )
        
        self.feature_dim = feature_dim
        
    def forward(self, x):
        """
        Args:
            x: (batch_size, 3, 224, 224) - 입력 이미지 (ImageNet normalized)
            
        Returns:
            (batch_size, feature_dim) - L2 정규화된 feature vector
        """
        # ResNet feature 추출
        features = self.backbone(x)  # (batch, 2048, 1, 1)
        features = torch.flatten(features, 1)  # (batch, 2048)
        
        # Projection (optional)
        if self.projection is not None:
            features = self.projection(features)
        
        # L2 normalization
        features = nn.functional.normalize(features, dim=1)
        
        return features
    
    def unfreeze_backbone(self):
        """Backbone을 학습 가능하도록 설정"""
        for param in self.backbone.parameters():
            param.requires_grad = True


class FeatureExtractor(ResNetFeatureExtractor):
    """Backward compatibility를 위한 alias"""
    pass
