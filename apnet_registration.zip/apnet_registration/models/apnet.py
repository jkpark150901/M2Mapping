"""APNet - Attribute Propagation Network

Paper: "Attribute Propagation Network for Graph Zero-shot Learning" (AAAI 2020)

모듈화된 구현:
- VisualEmbedding: 이미지 feature → embedding
- SemanticEncoder: Attribute → embedding
- AttributePropagation: GAT 기반 지식 전파
- Matching: Visual-semantic compatibility
"""

import torch
import torch.nn as nn
import torch.nn.functional as F

from .feature_extractor import ResNetFeatureExtractor
from .visual_embedding import VisualEmbedding
from .semantic_encoder import SemanticEncoder
from .attribute_propagation import AttributePropagation
from .gcn import GraphConvolution


class APNet(nn.Module):
    """APNet - Attribute Propagation Network (논문 구현)
    
    Args:
        visual_dim: Visual feature 차원 (2048 for ResNet-101)
        attribute_dim: Semantic attribute 차원 (85 for AwA2)
        embedding_dim: Embedding 차원
        num_classes: 클래스 수
        num_heads: Multi-head attention의 head 수
        num_layers: GAT layer 수
        dropout: Dropout 비율
        pretrained: ResNet pretrained 사용
        freeze_backbone: ResNet freeze 여부
    """
    def __init__(
        self,
        visual_dim=2048,
        attribute_dim=85,
        embedding_dim=512,
        num_classes=50,
        num_heads=4,
        num_layers=3,
        dropout=0.2,
        pretrained=True,
        freeze_backbone=True
    ):
        super(APNet, self).__init__()
        
        self.embedding_dim = embedding_dim
        self.num_classes = num_classes
        
        # 1. Visual Feature Extractor
        self.visual_extractor = ResNetFeatureExtractor(
            feature_dim=visual_dim,
            pretrained=pretrained,
            freeze_backbone=freeze_backbone
        )
        
        # 2. Visual Embedding
        self.visual_embedding = VisualEmbedding(
            visual_dim=visual_dim,
            embedding_dim=embedding_dim,
            dropout=dropout
        )
        
        # 3. Semantic Encoder
        self.semantic_encoder = SemanticEncoder(
            attribute_dim=attribute_dim,
            embedding_dim=embedding_dim
        )
        
        # 4. Attribute Propagation (GAT)
        self.attribute_propagation = AttributePropagation(
            embedding_dim=embedding_dim,
            num_heads=num_heads,
            num_layers=num_layers,
            dropout=dropout
        )
        
        # 5. Temperature parameter (learnable)
        self.temperature = nn.Parameter(torch.tensor(0.1))
        
        # 6. Classification head (간단한 linear)
        self.classifier = nn.Linear(embedding_dim, num_classes)
        
    def build_graph(self, attributes):
        """Attribute 유사도 기반 그래프 생성
        
        Args:
            attributes: (num_classes, attribute_dim)
            
        Returns:
            adj: (num_classes, num_classes) 인접 행렬
        """
        # L2 normalize
        attr_norm = F.normalize(attributes, p=2, dim=1)
        
        # Cosine similarity
        similarity = torch.mm(attr_norm, attr_norm.t())
        
        # Threshold (GAT가 알아서 필터링)
        threshold = 0.0
        adj = (similarity > threshold).float()
        
        return adj
    
    def forward(self, images, attributes, return_attention=False, use_semantic_matching=False):
        """
        Args:
            images: (batch, 3, 224, 224) - 입력 이미지
            attributes: (num_classes, attribute_dim) - 클래스 attributes
            return_attention: True면 attention weights 반환
            use_semantic_matching: True면 APNet 방식, False면 linear classifier
            
        Returns:
            logits: (batch, num_classes) - 예측 점수
        """
        # Step 1: Visual Feature Extraction & Embedding
        visual_features = self.visual_extractor(images)
        visual_emb = self.visual_embedding(visual_features)
        
        if not use_semantic_matching:
            # Stage 1: Simple classification (warm-up)
            logits = self.classifier(visual_emb)
            return logits
        
        # APNet with Attribute Propagation (논문 방식)
        # Step 2: Build Graph from Attributes
        adj = self.build_graph(attributes)
        
        # Step 3: Semantic Encoding
        attr_emb = self.semantic_encoder(attributes)
        
        # Step 4: Attribute Propagation (GAT)
        semantic_prototypes = self.attribute_propagation(attr_emb, adj)  # (num_classes, 512)
        
        # Step 5: Visual-Semantic Matching
        # L2 normalize for stable training
        visual_norm = nn.functional.normalize(visual_emb, p=2, dim=1)
        semantic_norm = nn.functional.normalize(semantic_prototypes, p=2, dim=1)
        
        # Cosine similarity with temperature scaling
        logits = torch.mm(visual_norm, semantic_norm.t())  # (batch, num_classes), range: [-1, 1]
        
        # Scale up (temperature를 나누는 것과 동일한 효과)
        temperature = 0.07
        logits = logits / temperature  # 더 sharp하게
        
        if return_attention:
            return logits, adj
        return logits
    
    def unfreeze_backbone(self):
        """ResNet backbone fine-tuning 활성화"""
        self.visual_extractor.unfreeze_backbone()


class APNetSimple(nn.Module):
    """APNet 경량 버전 (빠른 실험용)
    
    GAT 대신 GCN 사용
    """
    def __init__(
        self,
        visual_dim=2048,
        attribute_dim=85,
        embedding_dim=512,
        num_classes=50,
        pretrained=True,
        freeze_backbone=True
    ):
        super(APNetSimple, self).__init__()
        
        # Visual
        self.visual_extractor = ResNetFeatureExtractor(
            feature_dim=visual_dim,
            pretrained=pretrained,
            freeze_backbone=freeze_backbone
        )
        self.visual_embedding = VisualEmbedding(
            visual_dim=visual_dim,
            embedding_dim=embedding_dim,
            dropout=0.2
        )
        
        # Semantic
        self.semantic_encoder = SemanticEncoder(
            attribute_dim=attribute_dim,
            embedding_dim=embedding_dim,
            num_classes=num_classes
        )
        
        # GCN (GAT 대신)
        self.gcn1 = GraphConvolution(embedding_dim, embedding_dim)
        self.gcn2 = GraphConvolution(embedding_dim, embedding_dim)
        
        # Temperature
        self.temperature = nn.Parameter(torch.tensor(15.0))
        
    def forward(self, images, attributes, adj_matrix):
        """
        Args:
            images: (batch, 3, 224, 224)
            attributes: (num_classes, attribute_dim)
            adj_matrix: (num_classes, num_classes) - 미리 계산된 그래프
        """
        # Visual
        visual_feat = self.visual_extractor(images)
        visual_emb = self.visual_embedding(visual_feat)
        visual_emb = F.normalize(visual_emb, dim=1)
        
        # Semantic
        attr_emb = self.semantic_encoder(attributes)
        x = F.relu(self.gcn1(attr_emb, adj_matrix))
        semantic_emb = self.gcn2(x, adj_matrix)
        semantic_emb = F.normalize(semantic_emb, dim=1)
        
        # Matching
        logits = torch.mm(visual_emb, semantic_emb.t()) * self.temperature
        return logits
    
    def unfreeze_backbone(self):
        self.visual_extractor.unfreeze_backbone()
