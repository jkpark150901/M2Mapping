"""Attribute Propagation Module

GAT를 통한 attribute propagation
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from .graph_attention import MultiHeadGATLayer


class AttributePropagation(nn.Module):
    """Graph Attention Network을 통한 Attribute Propagation
    
    Args:
        embedding_dim: Embedding 차원
        num_heads: Multi-head attention의 head 수
        num_layers: GAT layer 수
        dropout: Dropout 비율
    """
    def __init__(
        self,
        embedding_dim=512,
        num_heads=4,
        num_layers=3,
        dropout=0.2
    ):
        super(AttributePropagation, self).__init__()
        
        self.num_layers = num_layers
        self.gat_layers = nn.ModuleList()
        
        # Simpler: 1 layer GAT만 사용
        self.gat_layers.append(
            MultiHeadGATLayer(
                embedding_dim,
                embedding_dim,
                num_heads=1,  # head도 1개로
                dropout=dropout,
                concat=False
            )
        )
        
        # Final projection 제거 - 불필요한 변환
    
    def forward(self, attr_emb, adj_matrix):
        """
        Args:
            attr_emb: (num_classes, embedding_dim) - Attribute embeddings
            adj_matrix: (num_classes, num_classes) - Adjacency matrix
            
        Returns:
            (num_classes, embedding_dim) - Propagated semantic prototypes
        """
        x = attr_emb
        
        # Single GAT layer with residual
        for gat_layer in self.gat_layers:
            x_new = gat_layer(x, adj_matrix)
            x = x + x_new  # Residual connection
        
        return x
