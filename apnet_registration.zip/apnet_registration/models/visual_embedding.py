"""Visual Embedding Module

이미지에서 추출된 feature를 embedding space로 변환
"""

import torch.nn as nn


class VisualEmbedding(nn.Module):
    """Visual Feature를 Embedding Space로 변환
    
    Args:
        visual_dim: 입력 visual feature 차원 (2048 for ResNet-101)
        embedding_dim: 출력 embedding 차원
        dropout: Dropout 비율
    """
    def __init__(self, visual_dim=2048, embedding_dim=512, dropout=0.2):
        super(VisualEmbedding, self).__init__()
        
        self.projection = nn.Sequential(
            nn.Linear(visual_dim, embedding_dim),
            nn.Dropout(dropout)
        )
    
    def forward(self, x):
        """
        Args:
            x: (batch, visual_dim) - Visual features
            
        Returns:
            (batch, embedding_dim) - Embedded features
        """
        return self.projection(x)
