"""Graph Attention Layer for APNet

APNet 논문의 핵심: Attention 기반 동적 그래프 생성 및 전파
"""

import torch
import torch.nn as nn
import torch.nn.functional as F


class GraphAttentionLayer(nn.Module):
    """Graph Attention Layer (GAT)
    
    APNet에서 사용하는 attention mechanism:
    - 각 노드가 이웃의 중요도를 동적으로 학습
    - Multi-head attention 지원
    
    Args:
        in_features: 입력 feature 차원
        out_features: 출력 feature 차원
        dropout: Dropout 비율
        alpha: LeakyReLU의 negative slope
        concat: Multi-head일 때 concat 여부
    """
    def __init__(self, in_features, out_features, dropout=0.2, alpha=0.2, concat=True):
        super(GraphAttentionLayer, self).__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.dropout = dropout
        self.alpha = alpha
        self.concat = concat
        
        # Weight matrix
        self.W = nn.Parameter(torch.zeros(size=(in_features, out_features)))
        nn.init.xavier_uniform_(self.W.data, gain=1.414)
        
        # Attention parameters
        self.a = nn.Parameter(torch.zeros(size=(2 * out_features, 1)))
        nn.init.xavier_uniform_(self.a.data, gain=1.414)
        
        self.leakyrelu = nn.LeakyReLU(self.alpha)
        
    def forward(self, h, adj):
        """
        Args:
            h: (N, in_features) - 노드 features
            adj: (N, N) - 인접 행렬 (0/1 또는 가중치)
            
        Returns:
            (N, out_features) - Attention이 적용된 출력
        """
        # Linear transformation
        Wh = torch.mm(h, self.W)  # (N, out_features)
        N = Wh.size(0)
        
        # Attention mechanism
        # Self-attention: a^T [Wh_i || Wh_j]
        Wh1 = torch.mm(Wh, self.a[:self.out_features, :])  # (N, 1)
        Wh2 = torch.mm(Wh, self.a[self.out_features:, :])  # (N, 1)
        
        # Broadcast add: (N, 1) + (1, N) = (N, N)
        e = Wh1 + Wh2.t()  # (N, N)
        e = self.leakyrelu(e)
        
        # Mask with adjacency matrix (only attend to neighbors)
        zero_vec = -9e15 * torch.ones_like(e)
        attention = torch.where(adj > 0, e, zero_vec)
        
        # Softmax normalization
        attention = F.softmax(attention, dim=1)
        attention = F.dropout(attention, self.dropout, training=self.training)
        
        # Aggregate neighbors
        h_prime = torch.mm(attention, Wh)  # (N, out_features)
        
        if self.concat:
            return F.elu(h_prime)
        else:
            return h_prime


class MultiHeadGATLayer(nn.Module):
    """Multi-head Graph Attention Layer
    
    APNet에서 사용: 여러 attention head로 다양한 관계 학습
    
    Args:
        in_features: 입력 feature 차원
        out_features: 각 head의 출력 차원
        num_heads: Attention head 수
        dropout: Dropout 비율
        alpha: LeakyReLU negative slope
        concat: Head를 concat할지 average할지
    """
    def __init__(
        self, 
        in_features, 
        out_features, 
        num_heads=4, 
        dropout=0.2, 
        alpha=0.2, 
        concat=True
    ):
        super(MultiHeadGATLayer, self).__init__()
        self.num_heads = num_heads
        self.concat = concat
        
        # Multi-head attention layers
        self.attentions = nn.ModuleList([
            GraphAttentionLayer(
                in_features, 
                out_features, 
                dropout=dropout, 
                alpha=alpha, 
                concat=concat
            ) for _ in range(num_heads)
        ])
        
    def forward(self, h, adj):
        """
        Args:
            h: (N, in_features)
            adj: (N, N)
            
        Returns:
            (N, out_features * num_heads) if concat
            (N, out_features) if average
        """
        # Apply each attention head
        head_outputs = [att(h, adj) for att in self.attentions]
        
        if self.concat:
            # Concatenate heads
            return torch.cat(head_outputs, dim=1)
        else:
            # Average heads
            return torch.mean(torch.stack(head_outputs), dim=0)
