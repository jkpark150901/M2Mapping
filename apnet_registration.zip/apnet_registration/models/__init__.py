"""APNet 모델 컴포넌트 - 모듈화된 구조"""

# Feature Extractors
from .feature_extractor import FeatureExtractor, ResNetFeatureExtractor

# Embedding Modules
from .visual_embedding import VisualEmbedding
from .semantic_encoder import SemanticEncoder

# Graph Components
from .gcn import GraphConvolution
from .graph_attention import GraphAttentionLayer, MultiHeadGATLayer
from .attribute_propagation import AttributePropagation

# APNet Models
from .apnet import APNet, APNetSimple
from .apnet_awa2 import APNetAwA2, APNetAwA2Simple

# Utilities
from .knowledge_graph import (
    create_awa2_knowledge_graph,
    visualize_graph_structure,
    compute_graph_statistics
)
from .trainer import (
    train_epoch,
    evaluate,
    train_model,
    evaluate_zsl
)
from .visualizer import (
    visualize_semantic_space,
    visualize_predictions,
    visualize_training_history,
    visualize_attribute_similarity,
    plot_class_distribution
)

__all__ = [
    # Feature Extractors
    'FeatureExtractor',
    'ResNetFeatureExtractor',
    # Embedding Modules
    'VisualEmbedding',
    'SemanticEncoder',
    # Graph Components
    'GraphConvolution',
    'GraphAttentionLayer',
    'MultiHeadGATLayer',
    'AttributePropagation',
    # APNet Models
    'APNet',              # 논문 원본 (GAT)
    'APNetSimple',        # 경량 버전 (GCN)
    'APNetAwA2',          # AWA2 전용 (ResNet + GCN)
    'APNetAwA2Simple',    # AWA2 경량 버전
    # Utilities
    'create_awa2_knowledge_graph',
    'visualize_graph_structure',
    'compute_graph_statistics',
    'train_epoch',
    'evaluate',
    'train_model',
    'evaluate_zsl',
    'visualize_semantic_space',
    'visualize_predictions',
    'visualize_training_history',
    'visualize_attribute_similarity',
    'plot_class_distribution'
]

