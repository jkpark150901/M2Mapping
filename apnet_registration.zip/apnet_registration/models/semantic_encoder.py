"""Semantic Encoder Module

Attribute를 semantic embedding space로 인코딩
"""

import torch.nn as nn


class SemanticEncoder(nn.Module):
    """Semantic Attribute를 Embedding Space로 인코딩
    
    Args:
        attribute_dim: Attribute 차원 (85 for AwA2)
        embedding_dim: 출력 embedding 차원
    """
    def __init__(self, attribute_dim=85, embedding_dim=512):
        super(SemanticEncoder, self).__init__()
        
        self.encoder = nn.Linear(attribute_dim, embedding_dim)
    
    def forward(self, attributes):
        """
        Args:
            attributes: (num_classes, attribute_dim) - Class attributes
            
        Returns:
            (num_classes, embedding_dim) - Encoded semantic features
        """
        return self.encoder(attributes)
