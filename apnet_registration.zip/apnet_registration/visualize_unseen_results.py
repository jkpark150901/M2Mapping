"""Unseen Classes 예측 결과 시각화"""

import torch
import torch.nn as nn
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from pathlib import Path
from sklearn.metrics import confusion_matrix
import json

from models import APNet
from awa2_data import AwA2Dataset
from awa2_image_dataset import create_awa2_dataloaders


def evaluate_unseen_detailed(model, test_loader, seen_attributes, unseen_attributes, device):
    """Unseen 클래스 상세 평가"""
    model.eval()
    
    all_labels = []
    all_preds = []
    all_probs = []
    class_correct = {i: 0 for i in range(10)}
    class_total = {i: 0 for i in range(10)}
    
    # 전체 attributes
    all_attributes = torch.cat([seen_attributes, unseen_attributes], dim=0).to(device)
    
    with torch.no_grad():
        for images, labels in test_loader:
            images = images.to(device)
            labels_np = labels.numpy()
            labels = labels.to(device)
            
            # Forward
            logits = model(images, all_attributes, use_semantic_matching=True)
            logits_unseen = logits[:, 40:]  # Unseen 클래스만
            
            probs = torch.softmax(logits_unseen, dim=1)
            predicted = logits_unseen.argmax(dim=1)
            
            # 저장
            all_labels.extend(labels_np)
            all_preds.extend(predicted.cpu().numpy())
            all_probs.extend(probs.cpu().numpy())
            
            # 클래스별 정확도
            for label, pred in zip(labels_np, predicted.cpu().numpy()):
                class_total[label] += 1
                if label == pred:
                    class_correct[label] += 1
    
    return {
        'labels': np.array(all_labels),
        'predictions': np.array(all_preds),
        'probabilities': np.array(all_probs),
        'class_correct': class_correct,
        'class_total': class_total
    }


def plot_confusion_matrix(results, class_names, save_path):
    """Confusion Matrix 시각화"""
    cm = confusion_matrix(results['labels'], results['predictions'])
    
    plt.figure(figsize=(12, 10))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', 
                xticklabels=class_names, yticklabels=class_names)
    plt.title('Confusion Matrix - Unseen Classes', fontsize=16)
    plt.ylabel('True Label', fontsize=12)
    plt.xlabel('Predicted Label', fontsize=12)
    plt.xticks(rotation=45, ha='right')
    plt.yticks(rotation=0)
    plt.tight_layout()
    plt.savefig(save_path, dpi=300, bbox_inches='tight')
    print(f"  Confusion matrix saved: {save_path}")
    plt.close()


def plot_class_accuracy(results, class_names, save_path):
    """클래스별 정확도 막대 그래프"""
    class_acc = []
    for i in range(10):
        total = results['class_total'][i]
        correct = results['class_correct'][i]
        acc = 100.0 * correct / total if total > 0 else 0
        class_acc.append(acc)
    
    plt.figure(figsize=(14, 6))
    bars = plt.bar(range(10), class_acc, color='skyblue', edgecolor='navy', alpha=0.7)
    
    # 각 막대 위에 값 표시
    for i, (bar, acc) in enumerate(zip(bars, class_acc)):
        height = bar.get_height()
        plt.text(bar.get_x() + bar.get_width()/2., height + 1,
                f'{acc:.1f}%\n({results["class_correct"][i]}/{results["class_total"][i]})',
                ha='center', va='bottom', fontsize=9)
    
    plt.axhline(y=np.mean(class_acc), color='r', linestyle='--', 
                label=f'Average: {np.mean(class_acc):.2f}%')
    plt.axhline(y=10, color='gray', linestyle=':', label='Random: 10%')
    
    plt.xlabel('Unseen Classes', fontsize=12)
    plt.ylabel('Accuracy (%)', fontsize=12)
    plt.title('Per-Class Accuracy on Unseen Classes', fontsize=16)
    plt.xticks(range(10), class_names, rotation=45, ha='right')
    plt.ylim(0, 105)
    plt.legend()
    plt.grid(axis='y', alpha=0.3)
    plt.tight_layout()
    plt.savefig(save_path, dpi=300, bbox_inches='tight')
    print(f"  Class accuracy plot saved: {save_path}")
    plt.close()


def plot_prediction_distribution(results, class_names, save_path):
    """예측 분포 히트맵"""
    # 각 true class에 대해 predicted class 분포
    distribution = np.zeros((10, 10))
    for true_label, pred_label in zip(results['labels'], results['predictions']):
        distribution[true_label][pred_label] += 1
    
    # 각 row를 percentage로 변환
    distribution_pct = distribution / distribution.sum(axis=1, keepdims=True) * 100
    
    plt.figure(figsize=(12, 10))
    sns.heatmap(distribution_pct, annot=True, fmt='.1f', cmap='YlOrRd',
                xticklabels=class_names, yticklabels=class_names,
                cbar_kws={'label': 'Percentage (%)'})
    plt.title('Prediction Distribution (Row-normalized %)', fontsize=16)
    plt.ylabel('True Label', fontsize=12)
    plt.xlabel('Predicted Label', fontsize=12)
    plt.xticks(rotation=45, ha='right')
    plt.yticks(rotation=0)
    plt.tight_layout()
    plt.savefig(save_path, dpi=300, bbox_inches='tight')
    print(f"  Prediction distribution saved: {save_path}")
    plt.close()


def analyze_errors(results, class_names, save_path):
    """오류 분석 및 저장"""
    error_analysis = {}
    
    for i in range(10):
        true_class = class_names[i]
        # 이 클래스에 대한 모든 예측
        mask = results['labels'] == i
        preds_for_class = results['predictions'][mask]
        
        if len(preds_for_class) == 0:
            continue
        
        # 가장 많이 오예측된 클래스들
        unique, counts = np.unique(preds_for_class, return_counts=True)
        pred_counts = dict(zip(unique, counts))
        
        # 정확도
        correct = results['class_correct'][i]
        total = results['class_total'][i]
        accuracy = 100.0 * correct / total
        
        # Top 3 predicted classes
        sorted_preds = sorted(pred_counts.items(), key=lambda x: x[1], reverse=True)[:3]
        top_predictions = [(class_names[int(pred_idx)], int(count), float(100*count/total)) 
                          for pred_idx, count in sorted_preds]
        
        error_analysis[true_class] = {
            'accuracy': f'{accuracy:.2f}%',
            'correct': int(correct),
            'total': int(total),
            'top_predictions': top_predictions
        }
    
    # JSON으로 저장
    with open(save_path, 'w') as f:
        json.dump(error_analysis, f, indent=2)
    
    print(f"  Error analysis saved: {save_path}")
    
    # 콘솔에도 출력
    print("\n" + "="*80)
    print("Error Analysis Summary")
    print("="*80)
    for class_name, stats in error_analysis.items():
        print(f"\n{class_name}:")
        print(f"  Accuracy: {stats['accuracy']} ({stats['correct']}/{stats['total']})")
        print(f"  Top predictions:")
        for pred_class, count, pct in stats['top_predictions']:
            print(f"    - {pred_class}: {count} ({pct:.1f}%)")


def main():
    print("="*80)
    print("Unseen Classes 예측 결과 시각화")
    print("="*80)
    
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    
    # 체크포인트 로드
    checkpoint_path = "results/train_semantic/20260130_024328/checkpoints/best_model.pth"
    print(f"\n체크포인트: {checkpoint_path}")
    
    checkpoint = torch.load(checkpoint_path)
    config = checkpoint['config']
    
    # 데이터 로딩
    dataset = AwA2Dataset()
    
    # Attributes
    awa2_base_dir = "/DATA/zeroshot/Animals_with_Attributes2"
    attr_file = f"{awa2_base_dir}/predicate-matrix-binary.txt"
    all_attributes_np = np.loadtxt(attr_file)
    
    seen_attr_list = []
    for class_name in dataset.seen_classes:
        class_idx = dataset.classes.index(class_name)
        seen_attr_list.append(all_attributes_np[class_idx])
    seen_attributes = torch.from_numpy(np.array(seen_attr_list)).float()
    
    unseen_attr_list = []
    for class_name in dataset.unseen_classes:
        class_idx = dataset.classes.index(class_name)
        unseen_attr_list.append(all_attributes_np[class_idx])
    unseen_attributes = torch.from_numpy(np.array(unseen_attr_list)).float()
    
    # 데이터로더
    image_dir = "/DATA/zeroshot/Animals_with_Attributes2/JPEGImages"
    _, _, test_unseen_loader = create_awa2_dataloaders(
        image_dir,
        dataset.seen_classes,
        dataset.unseen_classes,
        batch_size=64,
        num_workers=4
    )
    
    # 모델 로드
    model = APNet(
        visual_dim=config['visual_dim'],
        attribute_dim=config['attribute_dim'],
        embedding_dim=config['embedding_dim'],
        num_classes=50,
        num_heads=config.get('num_heads', 4),
        num_layers=config.get('num_layers', 3),
        dropout=config.get('dropout', 0.3),
        pretrained=False,
        freeze_backbone=False
    ).to(device)
    
    state_dict = checkpoint['model_state_dict']
    keys_to_remove = [k for k in state_dict.keys() if 'classifier' in k]
    for key in keys_to_remove:
        del state_dict[key]
    
    model.load_state_dict(state_dict, strict=False)
    model.eval()
    
    print("✓ 모델 로드 완료")
    
    # 상세 평가
    print("\n평가 진행 중...")
    results = evaluate_unseen_detailed(
        model, test_unseen_loader, seen_attributes, unseen_attributes, device
    )
    
    # 전체 정확도
    total_correct = sum(results['class_correct'].values())
    total_samples = sum(results['class_total'].values())
    overall_acc = 100.0 * total_correct / total_samples
    
    print(f"\n전체 정확도: {overall_acc:.2f}% ({total_correct}/{total_samples})")
    
    # 시각화 저장 경로
    vis_dir = Path("results/visualizations/unseen_test")
    vis_dir.mkdir(parents=True, exist_ok=True)
    
    print(f"\n시각화 저장 중: {vis_dir}")
    
    # Unseen class names
    unseen_names = [name.replace('+', ' ') for name in dataset.unseen_classes]
    
    # 1. Confusion Matrix
    plot_confusion_matrix(results, unseen_names, vis_dir / "confusion_matrix.png")
    
    # 2. Class Accuracy
    plot_class_accuracy(results, unseen_names, vis_dir / "class_accuracy.png")
    
    # 3. Prediction Distribution
    plot_prediction_distribution(results, unseen_names, vis_dir / "prediction_distribution.png")
    
    # 4. Error Analysis
    analyze_errors(results, unseen_names, vis_dir / "error_analysis.json")
    
    print("\n" + "="*80)
    print(f"시각화 완료! 결과: {vis_dir}")
    print("="*80)


if __name__ == "__main__":
    main()
